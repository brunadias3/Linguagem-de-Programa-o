/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proj_pedido;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author bruna
 */
public class Pedido {

    private int numero;
    private Cliente cliente;
    private Data data;
    private List<Item> lista;

    public Pedido(int numero, Cliente cliente, Data data) {
        this.numero = numero;
        this.cliente = cliente;
        this.data = data;
        lista = new ArrayList<Item>();
    }

    public void adicionaItem(Item item) {
        lista.add(item);
    }
    
    public void RemoveItem(Item item){
        lista.remove(item);
    }

    public double calcularTotal() {
        double total = 0;
        for (int i = 0; i < lista.size(); i++) {
            Item umItem = lista.get(i);
            total = total + umItem.calcularCustoItem();
        }
        return total;
    }

    public void imprimir() {
        cliente.imprimir();
        System.out.println("Pedido: " + numero);
        
        System.out.println("Itens:");
        for (int i = 0; i < lista.size(); i++) {
            Item umItem = lista.get(i);
            System.out.print("*");
            umItem.imprimir();
            System.out.println();
        }
        System.out.println("Total do pedido:" + calcularTotal());
    }

}
