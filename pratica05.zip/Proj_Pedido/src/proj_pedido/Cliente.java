/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proj_pedido;

/**
 *
 * @author bruna
 */
public class Cliente {
    protected String cli_nome;
    protected int cli_cpf;

    public Cliente(String cli_nome, int cli_cpf) {
        this.cli_nome = cli_nome;
        this.cli_cpf = cli_cpf;
    }

    public String getCli_nome() {
        return cli_nome;
    }

    public void setCli_nome(String cli_nome) {
        this.cli_nome = cli_nome;
    }

    public int getCli_cpf() {
        return cli_cpf;
    }

    public void setCli_cpf(int cli_cpf) {
        this.cli_cpf = cli_cpf;
    }
    
    public void imprimir(){
        System.out.println("Nome: " + cli_nome);
        System.out.println("CPF: " + cli_cpf);
    }
}
