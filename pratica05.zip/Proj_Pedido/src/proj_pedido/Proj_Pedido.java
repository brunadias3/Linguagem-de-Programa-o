/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proj_pedido;

/**
 *
 * @author bruna
 */
public class Proj_Pedido {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //TODO code application logic here
        Item item1, item2, item3;
        item1 = new Item(100, 3, 3);
        item2 = new Item(101, 2, 4);
        item3 = new Item(102, 1, 5);
        Cliente c1;
        Data d1;
        
        //cliente 
        c1 = new Cliente("bruna", 9999);
        
        //data
        d1 = new Data(22, 05, 2022);
        
        
        //pedido 
        Pedido pedido1 = new Pedido(1001,c1,d1);
        d1.formatarData(22, 05, 2022);
        pedido1.adicionaItem(item1);
        pedido1.adicionaItem(item2);
        pedido1.adicionaItem(item3);
        pedido1.imprimir();
        
        

    }

}
